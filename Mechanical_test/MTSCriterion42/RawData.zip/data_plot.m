clc; clear; close all;

%% Load data (TSV format)
% Columns: Crosshead [mm], Load [N], Time [s]
sample = {
    readtable("Test Run 8 12-15-23 16 43 32 PM\DAQ- Crosshead, … - (Timed).txt")
    readtable("Test Run 11 12-15-23 17 10 05 PM\DAQ- Crosshead, … - (Timed).txt")
    readtable("Test Run 13 12-15-23 17 11 28 PM\DAQ- Crosshead, … - (Timed).txt")
    readtable("Test Run 14 12-15-23 17 23 09 PM\DAQ- Crosshead, … - (Timed).txt")
    readtable("Test Run 15 12-15-23 17 35 06 PM\DAQ- Crosshead, … - (Timed).txt")
};
modulus = zeros(5, 1);
yield_stress = zeros(5,1);
yield_strain = zeros(5,1);
%% Plot
thickness = [3.667 3.983 3.730 3.850 3.683];
width = [3.167 3.250 3.316 3.350 3.450];
final_width = [1.500 1.450 1.416 1.600 1.733];
area = width .* thickness;
laterial_strain = (final_width - width)./width;
axial_strain = (80-28)/9.73;
poisson = -laterial_strain./axial_strain;


%%
strain_fn = @(l) (l-28)/9.73;

for i = 1:5
    strain = strain_fn(sample{i}.Crosshead); % [mm/mm]
    stress = sample{i}.Load./area(i); % [MPa]
    [peak_stress, loc, ~, ~] = findpeaks(stress, strain, 'MinPeakProminence', 1, 'NPeaks', 1);
    yield_strain(i) = loc;
    yield_stress(i) = peak_stress;
    
    index = find(strain > 0.02 & strain < yield_strain(i) - 0.02);
    b = regress(stress(index), [ones(size(index,1),1) strain(index)]);
    modulus(i) = b(2);

    plot(strain, stress);
    xlabel('engineering strain [mm/mm]');
    ylabel('engineering stress [MPa]');
    hold on;
end